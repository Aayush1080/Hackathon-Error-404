"""Browser end-to-end test of the whole workflow (brief tests 1-3 through the real UIs).

Needs: API on :8000, public app on :5174 and admin dashboard on :5173, all built with
VITE_API_URL=http://localhost:8000 (see README "Testing"). Usage: python e2e/e2e_test.py
External hosts (map tiles, geocoding) are blocked so the test only depends on the local stack."""
import random
import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw
from playwright.sync_api import expect, sync_playwright

OUT = Path(__file__).resolve().parent / "screenshots"
OUT.mkdir(exist_ok=True)
APP, ADMIN = "http://localhost:5174", "http://localhost:5173"
EMAIL, PASSWORD = sys.argv[1:3] if len(sys.argv) > 2 else ("admin@morisafe.test", "Admin-Pass-123")
RUN = "%06x" % random.randrange(16 ** 6)  # unique per run, so earlier runs' reports never match
DESC = f"Water across both lanes near the bus station (end-to-end test {RUN})"
LOCAL = re.compile(r"^https?://(localhost|127\.0\.0\.1)(:\d+)?/")


def photo() -> Path:
    img = Image.new("RGB", (1200, 900), (70, 130, 180))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 600, 1200, 900], fill=(40, 90, 140))
    d.text((40, 40), "MoriSafe E2E test photo", fill=(255, 255, 255))
    p = OUT / "test-photo.jpg"
    img.save(p, "JPEG")
    return p


def block_external(context):
    context.route(lambda url: not LOCAL.match(url), lambda route: route.abort())


def main():
    errors = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch()

        # ---- 1. A member of the public submits a report from a phone
        phone = browser.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True,
                                    geolocation={"latitude": -20.1609 + random.uniform(-0.03, 0.03), "longitude": 57.5012 + random.uniform(-0.03, 0.03)}, permissions=["geolocation"])
        block_external(phone)
        page = phone.new_page()
        page.on("console", lambda m: m.type == "error" and "ERR_FAILED" not in m.text and errors.append(("app", m.text)))
        page.goto(APP)
        expect(page.locator("h1", has_text="MoriSafe")).to_be_visible()
        expect(page.locator(".sync")).to_contain_text("Updated")
        page.screenshot(path=OUT / "01-app-alerts.png")

        page.locator("nav button", has_text="Report").click()
        page.wait_for_function("document.querySelector('#rl') && document.querySelector('#rl').value.length > 0", timeout=15000)
        page.click("button[data-cat='Flooding']")
        page.fill("#rd", DESC)
        with page.expect_file_chooser() as chooser:
            page.click("button[data-a='gal']")
        chooser.value.set_files(str(photo()))
        expect(page.locator("img[alt='Attached photo preview']")).to_be_visible()
        page.screenshot(path=OUT / "02-app-report-form.png")
        page.click("#sendbtn")
        expect(page.locator("h1", has_text="Report received")).to_be_visible(timeout=20000)
        page.screenshot(path=OUT / "03-app-report-received.png")
        print("PASS 1  report submitted from the phone UI; success shown only after the server saved it")

        page.locator("nav button", has_text="Alerts").click()
        page.click("button[data-a='refresh']")
        page.wait_for_timeout(800)
        assert DESC not in page.content(), "pending report must not be public"
        print("PASS 1b pending report is not in the public alerts")

        # ---- 2. An administrator reviews and approves it in the dashboard
        desk = browser.new_context(viewport={"width": 1366, "height": 900})
        block_external(desk)
        adm = desk.new_page()
        adm.on("console", lambda m: m.type == "error" and "ERR_FAILED" not in m.text and errors.append(("admin", m.text)))
        adm.goto(ADMIN + "/admin")
        adm.fill("input[type=email]", EMAIL)
        adm.fill("input[type=password]", "wrong-password")
        adm.click("button:has-text('Sign in')")
        expect(adm.get_by_role("alert")).to_contain_text("incorrect")
        adm.fill("input[type=password]", PASSWORD)
        adm.click("button:has-text('Sign in')")
        expect(adm.locator("h1", has_text="Overview")).to_be_visible()
        adm.fill("input[placeholder='Search reports…']", RUN)
        row = adm.locator("tbody tr").first
        expect(row).to_contain_text("pending")
        adm.screenshot(path=OUT / "04-admin-overview.png")
        row.locator("button[title='View']").click()
        img = adm.locator("img[alt='Photo submitted with the report']")
        expect(img).to_be_visible()
        adm.wait_for_function("(() => { const i = document.querySelector(\"img[alt='Photo submitted with the report']\"); return i && i.complete && i.naturalWidth > 0 })()")
        adm.screenshot(path=OUT / "05-admin-report-detail.png")
        print("PASS 2  admin signed in (wrong password rejected), opened the report and its photo loaded")
        adm.click("button:has-text('Approve & publish')")
        adm.click("button:has-text('Confirm')")
        expect(adm.get_by_role("status")).to_contain_text("approved and published")
        expect(adm.locator("[role=dialog]").first).to_contain_text("from pending to approved")
        adm.screenshot(path=OUT / "06-admin-approved.png")
        print("PASS 2b approval saved and recorded in the report history")
        adm.keyboard.press("Escape")
        adm.goto(ADMIN + "/admin/map")
        expect(adm.locator("path.leaflet-interactive").first).to_be_visible()
        adm.screenshot(path=OUT / "07-admin-map.png")

        # ---- 3. The approved report appears in the public app with its photo
        page.click("button[data-a='refresh']")
        card = page.locator(".card", has_text=DESC)
        expect(card).to_be_visible(timeout=10000)
        page.wait_for_function("[...document.querySelectorAll('.incident-photo')].some(i => i.complete && i.naturalWidth > 0)")
        card.scroll_into_view_if_needed()
        page.screenshot(path=OUT / "08-app-alert-published.png")
        card.locator("button[data-a='seemap']").click()
        expect(page.locator(".photo-pin").first).to_be_visible()
        page.screenshot(path=OUT / "09-app-map.png")
        print("PASS 3  approved report shown in Alerts with its photo and on the map")

        page.locator("nav button", has_text="Profile").click()
        expect(page.locator(".card", has_text="Your reports")).to_contain_text("APPROVED")
        page.screenshot(path=OUT / "10-app-profile.png")
        print("PASS 3b the reporter's own phone shows the report as approved")

        page.locator("nav button", has_text="Contacts").click()
        expect(page.locator("a[href='tel:114']")).to_contain_text("SAMU")
        browser.close()

    # the deliberate wrong-password attempt makes the browser log one 401; anything else is a failure
    first_401 = next((e for e in errors if e[0] == "admin" and "401" in e[1]), None)
    if first_401:
        errors.remove(first_401)
    if errors:
        print("Console errors:", *errors, sep="\n  ")
        sys.exit(1)
    print("All end-to-end checks passed. Screenshots in", OUT)


if __name__ == "__main__":
    main()
